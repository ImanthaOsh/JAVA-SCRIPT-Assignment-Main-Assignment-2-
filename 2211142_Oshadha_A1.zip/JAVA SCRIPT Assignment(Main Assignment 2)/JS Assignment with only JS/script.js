function signIn(event) {
    event.preventDefault(); // Prevent form submission

    // Get the values of the username and password fields
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Perform authentication
    if (username === "admin" && password === "1111") {
        // If authentication succeeds, redirect to the Home page
        window.location.href = "home.html";
    } else {
        // If authentication fails, display an error message
        alert("Incorrect username or password. Please try again.");
    }
}

function signOut() {

    // Clear the values of the username and password fields
    // document.getElementById("username").value = "";
    // document.getElementById("password").value = "";
    window.location.href = "index.html";
}